﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
 
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

           
            var binding1 = new Binding("Value")
            {
                Source = SliderFontSize,
                Mode = BindingMode.TwoWay
            };
            Message.SetBinding(TextBlock.FontSizeProperty, binding1);

           
            var binding2 = new Binding("FontSize")
            {
                Source = Message,
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            };
            FontSizeBox.SetBinding(TextBox.TextProperty, binding2);
        }
    }
}